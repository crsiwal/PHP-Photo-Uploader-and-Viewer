export default {
  dashboard: {
    view: "VIEW_HOME",
  },
  user: {
    view: "VIEW_USER",
    add: "ADD_USER",
    update: "UPDATE_USER",
    delete: "DELETE_USER",
    status: "UPDATE_USER_STATUS",
  },
};
